#include "hopnet.h"

hopnet::hopnet()
{}

hopnet::hopnet(std::vector<int> v)
{	
	states=std::move(v);
	for(uint i=0;i<states.size();++i)
	{	double rf =std::rand()/RAND_MAX;
		bias.push_back(rf);
	}
}

void hopnet::set_memweight(std::vector<std::vector<int>>& imgs)
{
	weights.resize(imgs[0].size());
	for(uint l=0;l<imgs[0].size();l++)
		weights[l].resize(imgs[0].size());
	
	for(uint i=0;i<imgs[0].size();i++)
	{	
		for(uint j=i;j<imgs[0].size();j++)
		{	double weighsum= 0;
			for(auto& n: imgs)
				weighsum+=n[i]*n[j];

			weights[i][j]=weights[j][i]=weighsum/imgs.size();
			//(img1[i]*img1[j]+img2[i]*img2[j])/2.0;
		}

		weights[i][i] = 0;
	}

} 

void hopnet::initialize(int size)
{   for(int i=0;i<size;i++)
	{	int r = std::rand()%2;
		double rf = std::rand()/RAND_MAX;
		if(r==0) r= -1;
		states.push_back(r);	//-1 is spin down,1 is up
		bias.push_back(rf);
	}
	weights.resize(size);
	for(int l=0;l<size;l++)
		weights[l].resize(size);

	for(int k=0;k<size;k++)
	{	for(int j=k;j<size;j++)
		{	weights[k][j]=weights[j][k]=(double)std::rand()/RAND_MAX;
			
		}	
		weights[k][k] = 0;
	}

}

hopnet::hopnet(int s)
{
	initialize(s);
}

hopnet::hopnet(const hopnet &obj)
{
	states = obj.get_states();
	weights = obj.get_w();
	bias = obj.get_bias();
}

void hopnet::flip_state(int i)
{
	if(states[i]==1) states[i] = -1;
	else states[i] = 1;
}

float hopnet::get_E()
{	float E=0;
	for(uint i=0;i<states.size();i++)
	{	for(uint j=i+1;j<states.size();j++)
			E+=-0.5*weights[i][j]*states[i]*states[j];
		E+=bias[i]*states[i];
	}
	return E;
}

void hopnet::transition(float beta)
{	int rcoord = std::rand()%(int)states.size();
	float ediff = Ediff(rcoord);
	double A = std::min(1.0,(double)exp(-1.0*beta*ediff));
	if(A>double(std::rand())/RAND_MAX){
		flip_state(rcoord);
	}
}

float hopnet::Ediff(int state)
{	float Ediff=0;	
	for(uint j=0;j<states.size();j++)
		{	if(j==state) Ediff+=states[state]*bias[j];
			else Ediff+= -0.5*weights[state][j]*states[j]*states[state];

		}
	return -2.0*Ediff;
}

std::vector<std::vector<double>> hopnet::get_w() const
{	return weights;
}
std::vector<int> hopnet::get_states() const
{
	return states;
}
std::vector<double> hopnet::get_bias() const
{
	return bias;
}

void printstates(std::vector<int> states)
{
	for(auto s:states)
		std::cout<<s<<" ";
}

void printweights(std::vector<std::vector<double>> w)
{
	for(uint i=0;i<w[0].size();i++)
	{	for(uint j=0;j<w[0].size();j++)
			std::cout<<w[i][j]<<" ";
		std::cout<<"\n";
	}
}	
std::vector<int> readstate(std::string infile)
{	
	std::ifstream inf;
	inf.open(infile);
	if(!inf)
	{
		std::cout<<"Unable to open file "<<infile<<"\n";
		exit(1);
	}
	std::vector<int> redvec;
	char x;
	while(inf >> x)
	{	if(x=='1')
			redvec.push_back(1);
		else
			redvec.push_back(-1);
	}
	inf.close();
	return redvec;

}

void part1proj()
{	int size;
	std::cout<<"Enter the size of the grid"<<'\n';
	std::cin>>size;
	for(int cnfg=1;cnfg<=10;cnfg++){
		hopnet hnet(size);
		std::ofstream outfile;
		outfile.open("outputs/out_"+std::to_string(cnfg));
		for(int i=0;i<10000;i++)
		{	if(i%100)
				outfile<< i << " "<< hnet.get_E()<<"\n";
			hnet.transition(100);
		}
		outfile.close();
	}
}

void dump2file(hopnet& net, std::string filename)
{
	std::vector<int> states = net.get_states();
	std::vector<std::vector<double>> weights = net.get_w();
	std::ofstream out;
	out.open(filename);
	for(uint i=0;i<states.size();i++)
	{	out<< states[i]<<" ";
		for (uint j = 0; j < states.size(); ++j)
		{
			out<< weights[i][j]<< " ";
		}
		out<<"\n";
	}
	out.close(); 
}

void statecorruptor(hopnet& net,int k)
{	uint nstate = (net.get_states()).size();
	// for(uint i=0;i<nstate/4;i++)
	// {	if(std::rand()%2) net.flip_state(i);
	// }
	int i=0;
	while(i<k)
	{
		int rcoord=std::rand()%nstate;
		net.flip_state(rcoord);
		++i;
	}

}

void runMC(hopnet& net)
{	
	for(int i=0;i<1000000;++i)
		net.transition(100);
}

int main(int argc, char *argv[])
{	std::vector<std::vector<int>> vimgs;
	std::cout<<argc<<"\n";
	if(argc > 1)
		for(int i=1;i<argc;i++)
		{	vimgs.push_back(readstate(argv[i]));
			std::cout<<argv[i]<<"\n";
		}
	else
	{
		part1proj();
		exit(0);
	}
	// std::vector<int> im1 = readstate("inputFig1");
	// std::vector<int> im2 = readstate("inputFig2");
	// std::cout<<im1.size()<<"\n";
	// std::cout<<im2.size()<<"\n";
	// for(const int& u: im1)
	// 	std::cout<< u <<' ';
	//std::cout<<"\n";
	hopnet hnet(vimgs[0]);
	// vimgs.push_back(im1);
	// vimgs.push_back(im2);
	hnet.set_memweight(vimgs);
	statecorruptor(hnet,29);
	dump2file(hnet, "snapshot/smilb4.dat");

	runMC(hnet);
	dump2file(hnet, "snapshot/smilafter.dat");

	//printweights(hnet.get_w());
	return 0;
}

